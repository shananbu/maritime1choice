<div class="logo"> <img src="../images/logo.png"></div>
<div class="menu_hide"><i class="fa fa-bars" id="menu-toggle"></i></div>
<div class="top_right">
    <ul>
        <li class="top_pro">
            <!--<img src="images/profile.png">--><span> Welcome <?php echo $_SESSION['login_user'] ?>!</span>
        </li>
        <li class="log_out"><i class="fa fa-sign-out m-r-xs"></i> <a href="logout.php">Sign Out</a></li>
    </ul>
</div>