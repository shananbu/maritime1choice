<ul>
    <li><a href="adminHome.php">Home</a></li>
    <li><a href="categoryManager.php">Category</a></li>
    <li><a href="serviceManager.php">Services</a></li>
    <li><a href="newsManager.php">news</a></li>
    <li><a href="careerManager.php">Careers</a></li>
    <li><a href="clientManager.php">Clients</a></li>
</ul>